// Obtener todos los enlaces con la clase 'button-link'
const buttons = document.querySelectorAll('.button-link');

// Agregar un evento de 'mouseover' para activar la animación
buttons.forEach(button => {
    button.addEventListener('mouseover', () => {
        button.classList.add('active');
    });

    // Agregar un evento de 'mouseout' para revertir la animación
    button.addEventListener('mouseout', () => {
        button.classList.remove('active');
    });
});
