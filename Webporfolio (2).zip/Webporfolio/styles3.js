let numButtonClicks = 0;
function buttonClicked() {
    numButtonClicks = numButtonClicks + 1;
    document.getElementById("mainDiv").textContent =
        "Button Clicked times: " + numButtonClicks;
}
// script.js
window.addEventListener('scroll', () => {
    const elements = document.querySelectorAll('.fade-in-on-scroll');

    elements.forEach(element => {
        const position = element.getBoundingClientRect();

        // Si el elemento está en la vista (cuando llega al viewport)
        if (position.top < window.innerHeight && position.bottom >= 0) {
            element.classList.add('in-view');
        }
    });
});
